
export class Mod {
    enable() {}
    disable() {}
}
